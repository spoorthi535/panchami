package com.nttdata.firstApp;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "my first maven project" );
    }
}
