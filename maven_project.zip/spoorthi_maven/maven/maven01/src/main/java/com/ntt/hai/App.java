package com.ntt.hai;


public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "my first maven project" );
        product p=new product();
        p.printdata();
    }
}
